### Spring练习项目
该项目对应黑马SSM教程视频的P89-P106

使用方法：使用前必须先导入项目中提供的test.sql数据

### 知识点整理

##### 1.配置

Dao和Service在Spring的applicationContext.xml配置，Controller在SpringMVC的spring-mvc.xml

Spring和SpringMVC的配置是分开的

##### 2.关于url和资源访问的区别

注意，当我们点击用户管理或者角色管理，url显示的是user/list或role/list，而不是直接跳转到user-list.jsp页面或者role-list.jsp页面

因为这些页面的展示都需要数据，静态的jsp页面是不行的，所以要通过请求的方式先去创建ModelAndView

然后把在数据库中查询到的数据添加到ModelAndView，最终通过setViewName并返回该ModelAndView实现数据的动态变化和页面的展示

并且在spring-mvc.xml中我们配置了**内部资源视图解析器**，所以setViewName("user-list")最终会拼接成/pages/user-list.jsp

除此之外，我们还需要开启静态资源的访问：```xml <mvc:default-servlet-hadler/>```

因为DispatcherServlet会去Controller中找/pages/user-list.jsp对应的请求处理方法，但它是找不到的

因为/pages/user-list.jsp并不是请求，而是静态资源，所以要开静态资源让它找不到时交给默认的servlet去找静态资源

##### 3.Dao、Service、Controller的职责分明

在Controller中，我们只通过对应的请求去调用一些Service层的方法，不能直接在Controller中操作数据库

另外，在Dao中也只是写一些简单的Sql语句，当遇到一些比较复杂的业务，需要写很长的sql甚至多条sql时

我们也在service中注入jdbcTemplate，进行一些sql语句的执行

### 添加了拦截器

##### 注意：由于我们在配置中开启了静态资源访问权限，而它的优先级最高，所以没有被拦截器拦截

用户登录拦截器判断流程：

点击用户管理过着角色管理时-->拦截器判断是否登录

如果登录则放行，未登录则跳转到登录页面

提交登录请求后跳回菜单页面