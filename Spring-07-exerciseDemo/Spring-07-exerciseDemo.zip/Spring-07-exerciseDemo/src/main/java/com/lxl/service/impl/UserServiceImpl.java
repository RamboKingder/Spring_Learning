package com.lxl.service.impl;

import com.lxl.dao.RoleDao;
import com.lxl.dao.UserDao;
import com.lxl.domain.Role;
import com.lxl.domain.User;
import com.lxl.service.UserService;

import java.util.List;

public class UserServiceImpl implements UserService {

    private UserDao userDao;

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    private RoleDao roleDao;

    public void setRoleDao(RoleDao roleDao) {
        this.roleDao = roleDao;
    }

    @Override
    public List<User> list() {
        List<User> userList = userDao.findAll();
        // 在Service层封装userList中每个user的roles
        for (User user : userList) {
            Long userId = user.getId();
            // 将userId作为参数查询当前userId对应的role的集合数据
            List<Role> roles = roleDao.findRoleByUserId(userId);
            user.setRoles(roles);
        }
        return userList;
    }

    @Override
    public void save(User user, Long[] roleIds) {
        // 1.向sys_user中存入user
        Long userID = userDao.save(user);
        // 2.向sys_user_row中存入多条数据
        userDao.saveUserRoleRel(userID,roleIds);
    }

    @Override
    public void del(Long userId) {
        // 先删除sys_user_role中的数据
        userDao.delUserRoleRel(userId);
        // 再删除sys_user表中的数据
        userDao.del(userId);
    }

}
