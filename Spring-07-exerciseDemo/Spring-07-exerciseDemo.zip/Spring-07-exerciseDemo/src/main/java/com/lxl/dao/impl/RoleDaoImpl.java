package com.lxl.dao.impl;

import com.lxl.dao.RoleDao;
import com.lxl.domain.Role;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

public class RoleDaoImpl implements RoleDao {

    private JdbcTemplate jdbcTemplate;

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public List<Role> findAll() {
        // 多个查询用query() 单个查询用queryForObject()
        List<Role> roleList = jdbcTemplate.query("select * from sys_role", new BeanPropertyRowMapper<Role>(Role.class));
        return roleList;
    }

    @Override
    public void save(Role role) {
        // 主键是自增的，所以这里主键先写个null
        jdbcTemplate.update("insert into sys_role values (? , ?, ?)", null, role.getRoleName(), role.getRoleDesc());
    }

    @Override
    public List<Role> findRoleByUserId(Long userId) {
        List<Role> roles = jdbcTemplate.query("select * from sys_role where sys_role.id in (select roleId from sys_user_role where userId = ?)", new BeanPropertyRowMapper<Role>(Role.class), userId);
        return roles;
    }
}
