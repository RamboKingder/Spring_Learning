package com.lxl.service.impl;

import com.lxl.dao.RoleDao;
import com.lxl.domain.Role;
import com.lxl.service.RoleService;

import java.util.List;

public class RoleServiceImpl implements RoleService {

    private RoleDao roleDao;

    public void setRoleDao(RoleDao roleDao) {
        this.roleDao = roleDao;
    }

    @Override
    public List<Role> list() {
        List<Role> roleList = roleDao.findAll();
        return roleList;
    }

    @Override
    public void save(Role role) {
        this.roleDao.save(role);
    }
}
